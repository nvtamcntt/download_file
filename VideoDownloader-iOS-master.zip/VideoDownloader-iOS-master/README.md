# VideoDownloader-iOS

A work-in-progress video downloader for iOS.

Todo:
- Finish basic webview interaction.
- Set up a UI for saving and browsing saved videos.
- Set up CoreData logic for saving videos.
- Set up logic for downloading videos from app to the device photo library.
